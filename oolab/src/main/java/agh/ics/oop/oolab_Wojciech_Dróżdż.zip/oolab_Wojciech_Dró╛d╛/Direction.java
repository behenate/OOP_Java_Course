// Wojciech Dróżdż
package agh.ics.oop;

enum Direction{
    FORWARD,
    BACKWARD,
    LEFT,
    RIGHT
}

